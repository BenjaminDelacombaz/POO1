require_relative 'connection.rb'

require_relative 'Models/Category.rb'
require_relative 'Models/Client.rb'
require_relative 'Models/Order.rb'
require_relative 'Models/OrderItem.rb'
require_relative 'Models/Product.rb'

puts Order.first

=begin
cheap_products = []

Client.first.products
Client.first.orders.each do |order|
    order.products.cheap.each do |product|
        cheap_products.push product
    end
end

bulk_products = OrderItem.all.bulk(50).map do |orderItem|
    orderItem.product
end
=end


=begin
client1 = Client.create(firstname: 'Steven', lastname: 'Avelino')

category1 = Category.create(name: 'Phone', description: 'Phone section')
category2 = Category.create(name: 'Computers', description: 'Computers')

product1 = Product.create(name: 'Huawei Mate 10 Pro', price: 999.99, description: 'Chinese Smartphone', categories: [category1])
product2 = Product.create(name: 'Macbook Pro', price: 3000, description: 'Macbook')

order = Order.create(created_at: Date.new(2018,1,2), shipped_at: Date.new(2018,2,2), status: 1, client: client1)
order.order_items.build(quantity: 2, item_price: product1.price, product: product1)
order.save
=end




