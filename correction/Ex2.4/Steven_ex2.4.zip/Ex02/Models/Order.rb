class Order < ActiveRecord::Base
    def to.s
        calculate
    end

    def calculate
        order_items.collect {|oi| oi.item_price * oi.quantity}.reduce(:+)
    end
    
    has_many :order_items
    has_many :products, through: :order_items

    validates :products, presence: true

    belongs_to :client
end