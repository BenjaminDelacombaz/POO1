class Client < ActiveRecord::Base
    def to_s
        "#{firstname} #{lastname}"
    end

    has_many :orders
    has_many :ordered_products, -> { distinct }, through: :orders, source: :products

    validates :firstname, :lastname,
        presence: true,
        length: { minimum: 2 }
end