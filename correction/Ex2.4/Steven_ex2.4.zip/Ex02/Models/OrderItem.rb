class OrderItem < ActiveRecord::Base
    belongs_to :order
    belongs_to :product

    #:item_price = :product.price

    validates :quantity,
    presence: true,
    numericality: {
        greater_than_or_equal_to: 1
    }

    scope :bulk,
    -> (number = 100) {
        where("quantity >= ?", number)
    }
end