# Bundle require
require 'bundler'
Bundler.require

# Import database connexion
require_relative 'connection'

# Import migrations

# Import active records
require_relative 'Models/Client'
require_relative 'Models/Order'
require_relative 'Models/OrderItem'
require_relative 'Models/Product'
require_relative 'Models/Category'

#
# Programme principal
#
puts 'Les produis pas chers :'

Client.find(2).orders.each { |order| order.products.cheap.each { |product| puts product } }

cheapProducts = Client.find(2).products.cheap

puts 'Les grosses commandes :'

Client.find(2).orders.each { |order| order.order_items.bulk(50).each { |oitem| puts oitem.product } }

products = OrderItem.bulk(50).map {|oi| oi.product}

# Check validations
client = Client.find(1)
product = Product.find(3)

order = Order.new
order.status = 1
order.client = client
order.order_items.build(quantity: 0, item_price: product.price, product: product)