class Client < ActiveRecord::Base
  validates :firstname, length: { minimum: 2, maximum: 200 }
  validates :lastname, length: { minimum: 2, maximum: 200 }

  has_many :orders
  has_many :ordered_producs, -> { distinct }, through: :orders, source: :producs
end