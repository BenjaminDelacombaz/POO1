require_relative 'connection.rb'

require_relative 'Models/Category.rb'
require_relative 'Models/Client.rb'
require_relative 'Models/Order.rb'
require_relative 'Models/OrderItem.rb'
require_relative 'Models/Product.rb'

client = Client.new
category = Category.new
order = Order.new
orderItem = OrderItem.new
product = Product.new

client1 = Client.create(firstname: 'Steven', lastname: 'Avelino')

category1 = Category.create(name: 'Phone', description: 'Phone section')




