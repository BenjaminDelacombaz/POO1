class Client < ActiveRecord::Base
  has_many :orders
end