%w{Category Client Product Order OrderItem}.each {|file| require_relative "../Models/#{file}"}

product = Product.create(name: 'testProduct', price: 10, description: 'test')