class Client < ActiveRecord::Base
    def to_s
        "#{firstname} #{lastname}"
    end

    validates :firstname, presence: true, length: { minimum: 2 }
    validates :lastname, presence: true, length: { minimum: 2 }

    has_many :orders
end