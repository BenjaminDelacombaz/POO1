class OrderItem < ActiveRecord::Base
    belongs_to :order
    belongs_to :product

    validates :product, presence: true

    scope :bulk,
    -> (number = 100) {
        where("quantity >= ?", number)
    }
end